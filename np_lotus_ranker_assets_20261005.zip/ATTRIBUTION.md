# Private runtime asset bundle

LOTUS v11 (2026-04-13), Adriano Rutz, Jonathan Bisson, Pierre-Marie Allard.
Source: https://zenodo.org/records/19360665
License: CC BY 4.0. Normalized by RDKit 2026.03.3 default canonical tautomers;
charge-neutral connected structures only. No query IDs or labels used.

LightGBM 4.7.0 official PyPI wheel. MIT license retained in wheel metadata.
Source: https://pypi.org/project/lightgbm/4.7.0/
